import java.sql.*;
import java.util.Scanner;

public class DeleteDB {
    public static void deleteTable(Connection conn) throws SQLException {
        Scanner dataTable = new Scanner(System.in);
        System.out.println("Enter the number of the data table you like to delete data from: " + "\n" +
                "1.Clients" + "\n" +
                "2.Employees" + "\n" +
                "3.Appointments" + "\n" +
                "4.Addresses" + "\n" +
                "5.Finances" + "\n" +
                "6.All tables" + "\n");

        int response = dataTable.nextInt();

        switch (response) {
            case 1: {
                String displaySql = "Truncate table Clients";

                try (PreparedStatement query = conn.prepareStatement(displaySql)) {
                    ResultSet rs = query.executeQuery();
                    rs.close();

                    break;
                }

            }case 2: {
                String displaySql = "Truncate Table Employees";

                try (PreparedStatement query = conn.prepareStatement(displaySql)) {
                    ResultSet rs = query.executeQuery();
                    rs.close();

                    break;
                }

            }case 3: {
                String displaySql = "truncate table Appointments";

                try (PreparedStatement query = conn.prepareStatement(displaySql)) {
                    ResultSet rs = query.executeQuery();
                    rs.close();

                    break;
                }

            }case 4: {
                String displaySql = "Truncate table Addresses";

                try (PreparedStatement query = conn.prepareStatement(displaySql)) {
                    query.executeUpdate();

                    break;
                }

            }case 5: {
                String displaySql = "Truncate table Finances";

                try (PreparedStatement query = conn.prepareStatement(displaySql)) {
                   query.executeUpdate();

                    break;
                }

            }case 6: {
               /* String displaySql = "Truncate table Clients" +
                                    "Truncate table Employees" +
                                    "Truncate table Appointments" +
                                    "truncate table Addresses" +
                                    "truncate table Finances";
*/

                try (Statement query = conn.createStatement();) {
                    query.executeUpdate("Truncate table Clients");
                    query.executeUpdate("Truncate table Employees");
                    query.executeUpdate("Truncate table Addresses");
                    query.executeUpdate("Truncate table Appointments");
                    query.executeUpdate("Truncate table Finances");

                    System.out.println("All records have successfully been deleted.");

                    break;
                }
            }
        }

    }
    private static void deleteAddresses(Connection conn, ResultSet rs) throws SQLException{
        try (PreparedStatement query = conn.prepareStatement("Truncate table Addresses")) {
            System.out.println("Entries Deleted. \n");

            }
            rs.close();
            //query.executeUpdate();
        }

    }
